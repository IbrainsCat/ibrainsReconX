#!/bin/bash
pkg install -y git python nmap figlet toilet
pip install requests fpdf
